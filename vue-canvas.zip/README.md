# XBoard

Online whiteboard

## [Online](http://oxoyo.co/XBoard/)

## START

```
npm install

npm run serve
```
## Preview 
![](./documents/preview_003.png)

## Chat
![](./documents/qq_roup.png)

## License
[MIT](http://opensource.org/licenses/MIT)