/**
 * Created by OXOYO on 2019/5/18.
 *
 * 全局BUS
 */

import Vue from 'vue'

const bus = new Vue()

export default bus
