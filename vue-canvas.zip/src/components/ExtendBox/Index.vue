/**
* Created by OXOYO on 2019/6/27.
*
* ExtendBox
*/

<style scoped lang="less" rel="stylesheet/less"></style>

<template>
  <h1>TODO ExtendBox</h1>
</template>

<script>
  export default {
    name: 'ExtendBox'
  }
</script>
