/**
* Created by OXOYO on 2019/7/1.
*
* Navigator 导航器面板
*/

<style scoped lang="less" rel="stylesheet/less">
  .navigator {
    display: inline-block;
    width: 100%;
    height: 100%;
  }
</style>

<template>
  <div class="navigator" id="navigator"></div>
</template>

<script>
  export default {
    name: 'Navigator'
  }
</script>
