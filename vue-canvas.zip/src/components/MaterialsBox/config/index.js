/**
 * Created by OXOYO on 2019/7/11.
 *
 * 编辑器配置
 */

import $X from './$X'
import materials from './materials'

export default {
  $X,
  materials
}
