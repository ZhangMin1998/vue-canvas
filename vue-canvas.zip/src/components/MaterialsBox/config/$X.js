/**
 * Created by OXOYO on 2019/7/22.
 *
 * $X命名空间
 */

export default {
  fill: '#FFFFFF',
  lineColor: '#000000',
  lineWidth: 1,
  lineType: 'x-line',
  lineStyle: 'solid',
  startArrow: false,
  endArrow: false
}
